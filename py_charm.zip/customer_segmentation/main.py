import pandas as pd
import embeding_training
import clustering_train_predict

vector_size = 10
path = '.../'
csv_file = 'test_data'

#load original dataset
df = pd.read_csv(path + csv_file+'.csv', index_col=0).set_index('id')

# clean and get embedding of the text features (some events may be omitted here if they contained only noise)
DF_vectorized = embeding_training.clean_embed(df, vector_size)

# predict cluster of the samples that's left
predicted_labels = clustering_train_predict.cluster(DF_vectorized)

# add 'category' column to the original dataset and save it
df.loc[DF_vectorized.index, 'category'] = predicted_labels
df.to_csv(path + f'{csv_file}_with_labels.csv')