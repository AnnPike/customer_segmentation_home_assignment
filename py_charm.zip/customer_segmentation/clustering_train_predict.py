from sklearn.metrics import davies_bouldin_score as DB_score
from sklearn.metrics import silhouette_score as s_score
from sklearn.cluster import KMeans


def cluster(DF):

    X = DF.to_numpy()

    kmeans = KMeans(n_clusters=35, init='k-means++', random_state=0).fit(X)
    predicted_labels = kmeans.labels_
    db = DB_score(X, predicted_labels)
    s = s_score(X, predicted_labels)

    print('Silhuette: ', s, '\nDavies-Bouldin index: ', db)
    return predicted_labels


