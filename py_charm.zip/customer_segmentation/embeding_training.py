import pandas as pd
import numpy as np
import re
import itertools
import urllib
from collections import Counter
from gensim.models import Word2Vec



def get_relevant(column_name, df):
    '''cleans txt inside this column of df'''
    ser = df[column_name].copy()
    ser.replace(r'^\s*$', np.NaN, regex=True, inplace=True)
    ser.replace(r"""!"#$%&'()*+,-./:;<=>?@[\]^_`{|}~""", ' ', inplace=True)
    ser.replace(r"=.*=", ' ', inplace=True)
    for idx in ser[~ser.isna()].index:
        i = ser.loc[idx]
        clean_i = re.sub(r"www", '', i)
        clean_i = re.sub(r"http|https", '', clean_i)
        I = re.findall('([A-Z]+[a-z]*|[a-z]+)', clean_i)

        if column_name == 'domain' and len(I) > 1:
            I = [word.strip().lower() for word in I]
            df.loc[idx, 'extention'] = I[-1]
            #             I = I[:-1]
            I = [word.strip().lower() for word in I if len(word) >= 2]
        else:
            I = [word.strip().lower() for word in I if len(word) > 2]

        df.loc[idx, 'list_' + column_name] = ' '.join(I)
    df['list_' + column_name] = df['list_' + column_name].replace(r'^\s*$', np.NaN, regex=True)
    return None

def vectorize(sentence, model, df_words, vector_size):
    '''finds words from the dictionary of embedding model and transrom it to vector of size vector_size
    then it calculates weighted average of the words to get vectorization of the whole sentence
    input: sentence - list of words from one entry
    model - embedding model from gensim.models
    df_words - df of frequencies of words present in all entries
    output: a vector that represent all words in one entry'''
    frequent_words = []
    weights = []
    for word in sentence:
        if word in model.wv.index_to_key:
            frequent_words.append(word)
            weight = float(df_words.loc[word].item())
            weights.append(weight)
    #     print(weights)
    if len(frequent_words) > 0:
        X = model.wv[frequent_words] / np.log10(np.array(weight))
        X_sum = X.sum(0)
        return X_sum
    else:
        return np.zeros(vector_size)

def clean_embed(df, vector_size):

    # separate columns
    df['protocol'], df['domain'], df['path'], df['query'], df['fragment'] = zip(*df['url'].map(urllib.parse.urlsplit))
    # clean text columns
    get_relevant('title', df)
    get_relevant('fragment', df)
    get_relevant('path', df)
    get_relevant('domain', df)
    get_relevant('query', df)
    # bring together relevan columns
    df['total_text'] = df['list_title'].fillna('')+' '+df['list_path'].fillna('')+' '+df['list_fragment'].fillna('')+' '+df['list_domain'].fillna('')+' '+df['list_query'].fillna('')+' '+df['extention'].fillna('')
    df['total_text'].replace(r'^\s*$', np.NaN, regex=True, inplace=True)
    df['l'] = [type(s) for s in df['total_text']]
    df.drop(df['total_text'][df['l'] == float].index, inplace=True)

    # combine the columns together into sentences
    sentences = list(df['total_text'].str.split())
    combined = list(itertools.chain.from_iterable(sentences))


    #get dataframe of frequency of words
    counter_keys = Counter(combined).keys() # equals to list(set(words))
    counter_values = Counter(combined).values()
    df_words = pd.DataFrame({'counts': counter_values}, index=counter_keys)


    # the embeddign model. the parameters were chosen empiricaly
    model = Word2Vec(vector_size=vector_size, min_count=5, negative=50, seed=21)
    model.build_vocab(sentences)  # prepare the model vocabulary
    model.train(sentences, total_examples=model.corpus_count, epochs=model.epochs)
    model.save("word2vec.model")


    # vectorizing all words for each event - this decision had better clustering performance then when columns were embedded separately
    DF = pd.DataFrame(index=df.index)
    vec = [vectorize(sentence, model, df_words, vector_size) for sentence in sentences]
    DF[list(range(vector_size))] = np.array(vec)
    DF.isna().any().any()
    DF.replace([np.inf, -np.inf], 100, inplace=True)
    return DF