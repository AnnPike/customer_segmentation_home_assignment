# combine the columns together into sentences
sentences = list(df['total_text'].str.split())
combined = list(itertools.chain.from_iterable(sentences))

# get dataframe of frequency of words
counter_keys = Counter(combined).keys()  # equals to list(set(words))
counter_values = Counter(combined).values()
df_words = pd.DataFrame({'counts': counter_values}, index=counter_keys)

# the embeddign model. the parameters were chosen empiricaly
model = Word2Vec(vector_size=vector_size, min_count=5, negative=50, seed=21)
model.build_vocab(sentences)  # prepare the model vocabulary
model.train(sentences, total_examples=model.corpus_count, epochs=model.epochs)
model.save("word2vec.model")

# vectorizing all words for each event - this decision had better clustering performance then when columns were embedded separately
DF = pd.DataFrame(index=df.index)
vec = [vectorize(sentence, model, df_words, vector_size) for sentence in sentences]
DF[list(range(vector_size))] = np.array(vec)
DF.isna().any().any()
DF.replace([np.inf, -np.inf], 100, inplace=True)
return DF